module.exports = require('./templates/eslint/lib.eslintrc.cjs');
