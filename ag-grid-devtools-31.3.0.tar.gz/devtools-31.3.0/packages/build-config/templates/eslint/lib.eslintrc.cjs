const base = require('./base.eslintrc.cjs');

module.exports = {
  ...base,
};
