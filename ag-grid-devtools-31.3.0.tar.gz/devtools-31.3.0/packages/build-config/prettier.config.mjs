export { default } from './templates/prettier/prettier.config.mjs';
