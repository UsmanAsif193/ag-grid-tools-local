module.exports = [
  new SyntaxError(`This method has been deprecated

> | gridApi.setGetRowId();
  | ^^^^^^^^^^^^^^^^^^^^^`),
];
