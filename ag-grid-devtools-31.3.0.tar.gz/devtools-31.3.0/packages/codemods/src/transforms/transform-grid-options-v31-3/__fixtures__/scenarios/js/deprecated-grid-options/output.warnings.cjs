module.exports = [
    new SyntaxError(`The grid option "groupIncludeFooter" is deprecated. Please refer to the migration guide for more details: https://ag-grid.com/javascript-data-grid/upgrading-to-ag-grid-31-3/

> |   groupIncludeFooter: true,
  |   ^^^^^^^^^^^^^^^^^^^^^^^^`),
  new SyntaxError(`The grid option "groupIncludeTotalFooter" is deprecated. Please refer to the migration guide for more details: https://ag-grid.com/javascript-data-grid/upgrading-to-ag-grid-31-3/

> |   groupIncludeTotalFooter: true,
  |   ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^`),
];
