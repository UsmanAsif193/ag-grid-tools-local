import { type TransformManifest } from '@ag-grid-devtools/types';

const manifest: TransformManifest = {
  name: 'Transform Grid options v31.1',
  description: 'Transform deprecated Grid options',
};

export default manifest;
