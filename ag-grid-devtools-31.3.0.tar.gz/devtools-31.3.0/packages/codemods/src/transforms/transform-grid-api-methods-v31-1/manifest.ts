import { type TransformManifest } from '@ag-grid-devtools/types';

const manifest: TransformManifest = {
  name: 'Transform Grid API methods v31.1',
  description: 'Transform deprecated Grid API method invocations',
};

export default manifest;
