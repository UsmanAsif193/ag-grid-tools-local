export { default } from './migrate-legacy-js-grid-constructor';
