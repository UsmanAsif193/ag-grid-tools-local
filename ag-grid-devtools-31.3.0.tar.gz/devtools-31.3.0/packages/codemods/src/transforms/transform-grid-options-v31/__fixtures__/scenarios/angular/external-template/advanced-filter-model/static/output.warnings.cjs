module.exports = [
  new SyntaxError(`The grid option "advancedFilterModel" cannot be automatically migrated. Please refer to the migration guide for more details: https://ag-grid.com/javascript-data-grid/upgrading-to-ag-grid-31/

>  8 | @Component({
  | ^`),
];
