import { foo } from "bar";

console.log("Hello, world!");
