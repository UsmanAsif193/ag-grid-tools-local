import { hello } from "world";
console.log("Hello, world!");
