import { foo } from "bar";

import { hello } from "world";

console.log("Hello, world!");
