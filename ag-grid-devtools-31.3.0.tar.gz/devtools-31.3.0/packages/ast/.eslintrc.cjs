module.exports = require('@ag-grid-devtools/build-config/templates/eslint/lib.eslintrc.cjs');
