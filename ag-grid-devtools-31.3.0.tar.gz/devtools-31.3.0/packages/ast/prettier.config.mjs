export { default } from '@ag-grid-devtools/build-config/templates/prettier/prettier.config.mjs';
