export { basename, extname, resolve, relative } from 'node:path';
