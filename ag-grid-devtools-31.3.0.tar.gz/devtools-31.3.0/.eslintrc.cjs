module.exports = require('./packages/build-config/templates/eslint/lib.eslintrc.cjs');
